package sr;

public class Main {
    public static void main(String[] args) {
        UI ui = new UI();
        ui.launch();
    }
}
